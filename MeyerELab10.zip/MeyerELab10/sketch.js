let player;
let obstacle;

function setup() {
  createCanvas(600, 200);
  
  player = createSprite(50, 150, 20, 20);
  obstacle = createSprite(600, 150, 20, 40);
  
  obstacle.velocity.x = -4;
}

function draw() {
  background(200);

  // Jump
  if (keyWentDown("space") && player.position.y >= 150) {
    player.velocity.y = -10;
  }

  // Gravity
  player.velocity.y += 0.5;

  // Ground collision
  player.collide(createSprite(300, 180, 600, 20));

  // Reset obstacle
  if (obstacle.position.x < 0) {
    obstacle.position.x = 600;
  }

  // Collision detection
  if (player.collide(obstacle)) {
    text("Game Over", 250, 100);
    noLoop();
  }

  drawSprites();