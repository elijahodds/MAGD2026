function setup() {
  createCanvas(700, 520);
   colorMode(RGB, 255,255,255,1)
}

function draw() {
  background(0);
  noStroke();
  fill(175,100,220)
  circle(170,117,110)
  fill(100,220,10)
arc(170, 117, 110, 5, 0, PI + HALF_PI);
  fill(220,75,65)
arc(170, 157, 80, 5, 0, PI + HALF_PI);
arc(170, 85, 90, 5, 0, PI + HALF_PI);
  fill(35,130,50)
  rect(550,100,125,75)
triangle(550,100,450,135,550,175)
rect(650,120,40,40)
rect(675,130,20,20)
  fill(70)
rect(550,123,30,30)
  rect(590,123,30,30)
  rect(630,123,30,30)
  fill(215,230,112)
  circle(40,470,200)
  fill(135,30,72)
  rect(340,300,200,116)
  rect(320,320,100,80)
  rect(300,330,100,60)
  fill(220,240,12)
  quad(130,330,300,300,310,350,315,420)
  triangle(540,300,620,355,540,415)
}
