function setup() {
  createCanvas(700, 520);
  background(50);
  noStroke();
  fill(250);
 circle(120,120,150);
  fill(200);
  circle(240,240,135);
  fill(150);
  circle(260,260,25);
  fill(150);
  circle(250,250,25);
fill(150);
  circle(205,205,25);
  noFill();
  stroke(0);
  circle(400,300,25);
  stroke(255);
  fill(255);
  circle(400,300,15);
  line(400,300,390,350)
  line(390,350,375,375)
  line(390,350, 405,390)
  line(375,305,420,347)
  circle(300,10,10);
 circle(100,100,10);
 circle(170,470,10);
 circle(280,310,10);
 circle(560,410,10);
 circle(600,200,10);
 circle(70,350,10);
 circle(450,150,10);
rect(550,100,125,75)
triangle(550,100,450,135,550,175)
rect(650,120,40,40)
rect(675,130,20,20)
  strokeJoin(ROUND)
  stroke(0)
strokeWeight(5)
  fill(70)
rect(550,123,30,30)
  rect(590,123,30,30)
  rect(630,123,30,30)


}